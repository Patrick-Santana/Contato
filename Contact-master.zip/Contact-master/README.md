# Contact

Sistema de cadastro de usuários, atividades e contas pendente, utilizando Python/Django 

Comando para iniciar o servidor:
-python manage.py runserver

Comandos para atualizar as tabelas criadas:
-python manage.py migrate
-python manage.py migrate --run-syncdb

Comando para criar usuario que terá acesso ao sistema:
-python manage.py createsuperuser

                                                                                    Miguel Gabriel B. Dos Santos
                                                                                    15/02/2020
                                                                                    Em memoria de Miguel Israel
